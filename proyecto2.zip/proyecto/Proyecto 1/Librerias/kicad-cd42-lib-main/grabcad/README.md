Los diseño 3D es tomado de el repositorio de grabcad
https://grabcad.com/library/mh-cd42-tp5306-based-charge-5v-boost-board-1

El enlace del autor: https://grabcad.com/k.b-103
